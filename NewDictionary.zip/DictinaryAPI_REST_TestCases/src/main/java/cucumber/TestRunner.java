package main.java.cucumber;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "features",
		glue= "stepDefinition")

/*
 @RunWith(Cucumber.class)
 @CucumberOptions(
    format={"pretty"},
    features= "src/features/",
    glue = "cucumber.steps")
 public class cucumberRunner {}
 */

public class TestRunner {

}