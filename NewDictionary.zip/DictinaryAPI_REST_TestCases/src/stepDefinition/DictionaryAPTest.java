package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DictionaryAPTest
{
	WebDriver driver;
	
	//@Given("^you are in Given annotation$")
	@Given("^testGiven$")
	public void given() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://dictionaryapi.docs.apiary.io/");
	}
	
		@Given("^the dictionary URL link$")
		public void the_dictionary_URL_link() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   // throw new PendingException();
			
			System.out.println("the dictionary URL link");
		}

		@When("^Create new dictionary API is displayed$")
		public void create_new_dictionary_API_is_displayed() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   // throw new PendingException();
			System.out.println("Create new dictionary API is displayed");
		}

		@Then("^I click on it$")
		public void i_click_on_it() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   // throw new PendingException();
			System.out.println("I click on it");
		}

		@Then("^A New API window will open$")
		public void a_New_API_window_will_open() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		   // throw new PendingException();
			System.out.println("A New API window will open");
		}

		@Then("^I follow new dictionary procedure by having a unique ID$")
		public void i_follow_new_dictionary_procedure_by_having_a_unique_ID() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  //  throw new PendingException();
			System.out.println("I follow new dictionary procedure by having a unique ID");
		}

		@Then("^New Records will get posted with unique ID$")
		public void new_Records_will_get_posted_with_unique_ID() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		    //throw new PendingException();
			System.out.println("New Records will get posted with unique ID");
		}


}
	
	